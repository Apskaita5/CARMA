using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using A5Soft.CARMA.Application.DataPortal.Internal;
using A5Soft.CARMA.Domain;
using A5Soft.CARMA.Domain.Files;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace A5Soft.CARMA.Application.DataPortal
{
    /// <summary>
    /// The client side of the data portal. Turns a use case call into a canonical, transport
    /// independent request, hands it to the <see cref="IDataPortalProxy"/>, and turns the canonical
    /// response back into the result.
    /// </summary>
    /// <remarks>
    /// <para>Domain objects are sent as their DTOs and rebuilt from the DTOs received, with the
    /// client's own <see cref="IApplicationContext"/>.</para>
    /// <para>Uploads: any <see cref="FileContent"/> in the parameters (top-level, in a DTO, in a
    /// list) is detached and handed to the proxy as a <see cref="DataPortalFile"/>; the server
    /// reattaches it. The caller keeps owning the files; each stream is read once, as it is sent.</para>
    /// <para>Downloads: a <see cref="FileContent"/> result streams as it arrives, and the caller must
    /// dispose it to release the transport. A file nested in a result always arrives as null: files
    /// travel upstream only.</para>
    /// <para>Before the first call, the client fetches the <see cref="ServerSettings"/>
    /// (<see cref="IServerSettingsProvider"/>) and compares the server's application with its own
    /// (<see cref="IAppVersionProvider"/>), as <see cref="IDataPortalClientOptions.AppVersionMatch"/>
    /// directs: a mismatch fails every call with <see cref="RemoteErrorKind.VersionMismatch"/>, without
    /// sending it.</para>
    /// <para>The server's limits are enforced before sending and, for files of unknown length, while
    /// sending, whatever the transport.</para>
    /// </remarks>
    [DefaultServiceImplementation(typeof(IClientDataPortal))]
    public class ClientDataPortal : IClientDataPortal
    {
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false);

        private readonly IDataPortalProxy _proxy;
        private readonly RemoteUseCaseRegistry _registry;
        private readonly IApplicationContext _context;
        private readonly IRemoteErrorMapper _errorMapper;
        private readonly IDataPortalClientOptions _options;
        private readonly IServerSettingsProvider _settingsProvider;
        private readonly IAppVersionProvider _versionProvider;


        /// <summary>
        /// Creates a new client data portal.
        /// </summary>
        /// <param name="proxy">a transport to send the calls through</param>
        /// <param name="registry">a registry of the remote use cases</param>
        /// <param name="context">the client application context, for the domain objects rebuilt
        /// from the DTOs received</param>
        /// <param name="errorMapper">a mapper of remote errors to application exceptions</param>
        /// <param name="options">the client data portal options</param>
        /// <param name="settingsProvider">a provider of the server's settings</param>
        /// <param name="versionProvider">the identity of the client application, compared with the
        /// server's</param>
        public ClientDataPortal(IDataPortalProxy proxy, RemoteUseCaseRegistry registry,
            IApplicationContext context, IRemoteErrorMapper errorMapper, IDataPortalClientOptions options,
            IServerSettingsProvider settingsProvider, IAppVersionProvider versionProvider)
        {
            _proxy = proxy ?? throw new ArgumentNullException(nameof(proxy));
            _registry = registry ?? throw new ArgumentNullException(nameof(registry));
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _errorMapper = errorMapper ?? throw new ArgumentNullException(nameof(errorMapper));
            _options = options ?? throw new ArgumentNullException(nameof(options));
            _settingsProvider = settingsProvider ?? throw new ArgumentNullException(nameof(settingsProvider));
            _versionProvider = versionProvider ?? throw new ArgumentNullException(nameof(versionProvider));
        }


        /// <inheritdoc />
        public bool IsRemote => _proxy.IsRemote;


        #region Fetch

        /// <inheritdoc />
        public Task<(TResult Result, ClaimsIdentity Identity)> FetchAsync<TResult>(
            Type useCaseType, ClaimsIdentity identity)
            => FetchCoreAsync<TResult>(useCaseType, identity, CancellationToken.None);

        /// <inheritdoc />
        public Task<(TResult Result, ClaimsIdentity Identity)> FetchAsync<TArg, TResult>(
            Type useCaseType, TArg arg, ClaimsIdentity identity)
            => FetchCoreAsync<TResult>(useCaseType, identity, CancellationToken.None, arg);

        /// <inheritdoc />
        public Task<(TResult Result, ClaimsIdentity Identity)> FetchAsync<TArg1, TArg2, TResult>(
            Type useCaseType, TArg1 arg1, TArg2 arg2, ClaimsIdentity identity)
            => FetchCoreAsync<TResult>(useCaseType, identity, CancellationToken.None, arg1, arg2);

        /// <inheritdoc />
        public Task<(TResult Result, ClaimsIdentity Identity)> FetchAsync<TArg1, TArg2, TArg3, TResult>(
            Type useCaseType, TArg1 arg1, TArg2 arg2, TArg3 arg3, ClaimsIdentity identity)
            => FetchCoreAsync<TResult>(useCaseType, identity, CancellationToken.None, arg1, arg2, arg3);

        #endregion

        #region Invoke

        /// <inheritdoc />
        public Task<ClaimsIdentity> InvokeAsync(Type useCaseType, ClaimsIdentity identity)
            => InvokeCoreAsync(useCaseType, identity, CancellationToken.None);

        /// <inheritdoc />
        public Task<ClaimsIdentity> InvokeAsync<TArg>(Type useCaseType, TArg arg,
            ClaimsIdentity identity)
            => InvokeCoreAsync(useCaseType, identity, CancellationToken.None, arg);

        /// <inheritdoc />
        public Task<ClaimsIdentity> InvokeAsync<TArg1, TArg2>(Type useCaseType, TArg1 arg1,
            TArg2 arg2, ClaimsIdentity identity)
            => InvokeCoreAsync(useCaseType, identity, CancellationToken.None, arg1, arg2);

        /// <inheritdoc />
        public Task<ClaimsIdentity> InvokeAsync<TArg1, TArg2, TArg3>(Type useCaseType, TArg1 arg1,
            TArg2 arg2, TArg3 arg3, ClaimsIdentity identity)
            => InvokeCoreAsync(useCaseType, identity, CancellationToken.None, arg1, arg2, arg3);

        #endregion

        #region Core

        /// <summary>
        /// Invokes a remote method that returns a value. For a <see cref="FileContent"/> result,
        /// the caller must dispose it.
        /// </summary>
        /// <param name="useCaseType">a use case interface or implementation type</param>
        /// <param name="identity">an identity of the caller, holding the token claim; null for an
        /// anonymous call</param>
        /// <param name="cancellationToken">a token to cancel the call</param>
        /// <param name="args">the arguments, in the order of the remote method signature</param>
        public async Task<(TResult Result, ClaimsIdentity Identity)> FetchCoreAsync<TResult>(
            Type useCaseType, ClaimsIdentity identity, CancellationToken cancellationToken,
            params object[] args)
        {
            var descriptor = _registry.GetFor(useCaseType);

            if (null == descriptor.Result || !typeof(TResult).IsAssignableFrom(descriptor.Result.DeclaredType))
                throw new InvalidOperationException(
                    $"Remote method {descriptor.Name}.{descriptor.Method.Name} does not return {typeof(TResult)}.");

            var (result, refreshedIdentity) = await CallAsync(descriptor, identity, args, cancellationToken)
                .ConfigureAwait(false);

            return ((TResult)result, refreshedIdentity);
        }

        /// <summary>
        /// Invokes a remote method. The result, if the method has one, is discarded
        /// (a downloaded file is released unread).
        /// </summary>
        /// <param name="useCaseType">a use case interface or implementation type</param>
        /// <param name="identity">an identity of the caller, holding the token claim; null for an
        /// anonymous call</param>
        /// <param name="cancellationToken">a token to cancel the call</param>
        /// <param name="args">the arguments, in the order of the remote method signature</param>
        public async Task<ClaimsIdentity> InvokeCoreAsync(Type useCaseType, ClaimsIdentity identity,
            CancellationToken cancellationToken, params object[] args)
        {
            var descriptor = _registry.GetFor(useCaseType);

            var (result, refreshedIdentity) = await CallAsync(descriptor, identity, args, cancellationToken)
                .ConfigureAwait(false);

            (result as IDisposable)?.Dispose();

            return refreshedIdentity;
        }

        private async Task<(object Result, ClaimsIdentity Identity)> CallAsync(
            RemoteUseCaseDescriptor descriptor, ClaimsIdentity identity, object[] args,
            CancellationToken cancellationToken)
        {
            args = args ?? new object[] { null };

            if (args.Length != descriptor.Parameters.Count) throw new ArgumentException(
                $"Remote method {descriptor.Name}.{descriptor.Method.Name} takes " +
                $"{descriptor.Parameters.Count} parameter(s), {args.Length} given.", nameof(args));

            var settings = await GetServerSettingsAsync(cancellationToken)
                .ConfigureAwait(false);

            var request = CreateRequest(descriptor, identity, args, settings);

            DataPortalResponse response;
            try
            {
                response = await _proxy.SendAsync(request, cancellationToken).ConfigureAwait(false)
                    ?? throw new DataPortalTransportException(RemoteErrorKind.ServerError, "The proxy has returned no response.");
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception) when (null != request.LimitViolation)
            {
                // a file of unknown length turned out to be over the limits while it was sent
                throw LimitExceeded(request.LimitViolation);
            }
            catch (DataPortalTransportException ex)
            {
                if (ex.Kind == RemoteErrorKind.BadRequest || ex.Kind == RemoteErrorKind.VersionMismatch)
                    _settingsProvider.Invalidate();
                throw ToException(new RemoteError { Kind = ex.Kind }, ex);
            }

            if (null != request.LimitViolation)
            {
                // the server may have answered before the transport noticed that sending had failed
                response.Dispose();
                throw LimitExceeded(request.LimitViolation);
            }

            return ReadResponse(descriptor, response, settings);
        }

        #endregion

        #region Server settings

        /// <summary>
        /// Gets the server's settings, and checks that the server runs the same application, in a
        /// version that matches.
        /// </summary>
        private async Task<ServerSettings> GetServerSettingsAsync(CancellationToken cancellationToken)
        {
            ServerSettings settings;
            try
            {
                settings = await _settingsProvider.GetAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (DataPortalTransportException ex) when (ex.Kind == RemoteErrorKind.VersionMismatch)
            {
                // the server speaks another version of the transport protocol
                throw VersionMismatch(null, ex.Message, ex);
            }
            catch (DataPortalTransportException ex)
            {
                throw ToException(new RemoteError { Kind = ex.Kind }, ex);
            }

            var reason = GetMismatch(settings);
            if (null != reason)
            {
                // the server may be updated again while the client stays as it is
                _settingsProvider.Invalidate();
                throw VersionMismatch(settings, reason);
            }

            return settings;
        }

        private string GetMismatch(ServerSettings settings)
        {
            var clientName = _versionProvider.AppName;
            var clientVersion = _versionProvider.AppVersion;

            if (string.IsNullOrWhiteSpace(clientName) || null == clientVersion) throw new InvalidOperationException(
                $"{nameof(IAppVersionProvider)} must give both the name and the version of the application.");

            if (!string.Equals(clientName, settings.AppName, StringComparison.Ordinal))
                return $"the server runs application '{settings.AppName}', the client is '{clientName}'";

            if (!IsMatch(clientVersion, settings.AppVersion, _options.AppVersionMatch))
                return $"the server runs version {settings.AppVersion}, the client is version {clientVersion} " +
                    $"({_options.AppVersionMatch} match required)";

            return null;
        }

        /// <summary>
        /// Compares two versions; a missing build or revision counts as 0, so 1.4 matches 1.4.0.0.
        /// </summary>
        internal static bool IsMatch(Version client, Version server, AppVersionMatch match)
        {
            switch (match)
            {
                case AppVersionMatch.None:
                    return true;

                case AppVersionMatch.MajorMinor:
                    return client.Major == server.Major && client.Minor == server.Minor;

                default:
                    return client.Major == server.Major && client.Minor == server.Minor
                        && Math.Max(client.Build, 0) == Math.Max(server.Build, 0)
                        && Math.Max(client.Revision, 0) == Math.Max(server.Revision, 0);
            }
        }

        private Exception VersionMismatch(ServerSettings settings, string reason, Exception innerException = null)
        {
            var data = new VersionMismatchData
            {
                ClientAppName = _versionProvider.AppName,
                ClientAppVersion = _versionProvider.AppVersion,
                ServerAppName = settings?.AppName,
                ServerAppVersion = settings?.AppVersion,
                AppVersionMatch = _options.AppVersionMatch,
                Reason = reason
            };

            return ToException(new RemoteError
            {
                Kind = RemoteErrorKind.VersionMismatch,
                Data = JToken.FromObject(data, DataPortalSerialization.CreateSerializer(DataPortalSerialization.PortalMessageMaxDepth))
            }, innerException ?? new InvalidOperationException($"Version mismatch: {reason}."));
        }

        #endregion

        #region Request

        private DataPortalRequest CreateRequest(RemoteUseCaseDescriptor descriptor, ClaimsIdentity identity,
            object[] args, ServerSettings settings)
        {
            // the parameters as JSON, with every file detached and replaced by a reference
            var files = new OutgoingFiles();
            var serializer = DataPortalSerialization.CreateSerializer(settings.MaxDepth);
            serializer.Context = new StreamingContext(StreamingContextStates.Remoting, files);

            var payload = new MemoryStream();
            using (var textWriter = new StreamWriter(payload, Utf8, 4096, true))
            using (var jsonWriter = new JsonTextWriter(textWriter))
            {
                jsonWriter.WriteStartArray();
                for (var i = 0; i < args.Length; i++) descriptor.Parameters[i].Write(jsonWriter, serializer, args[i]);
                jsonWriter.WriteEndArray();
            }

            CheckLimits(payload.Length, files.Files, settings);

            string token = null;
            if (null != identity)
            {
                token = identity.FindFirst(_options.TokenClaimType)?.Value;

                if (string.IsNullOrEmpty(token)) throw new InvalidOperationException(
                    $"The identity has no {_options.TokenClaimType} claim to authenticate the call with.");
            }

            var call = new DataPortalCall(descriptor.Name, descriptor.ParameterTypeNames, token,
                CultureInfo.CurrentCulture.Name, CultureInfo.CurrentUICulture.Name, files.Files.Count);

            // every file is counted as the proxy reads it, so a file of unknown length over a limit
            // is stopped before its excess is sent
            var tracker = new SendTracker(settings.MaxFileLength, settings.MaxUploadLength);
            var outgoing = files.Files
                .Select(f => new DataPortalFile(f.FileName, f.ContentType, tracker.Track(f.Content, f.FileName), KnownLength(f)))
                .ToList();

            return new DataPortalRequest(call, new ArraySegment<byte>(payload.GetBuffer(), 0, (int)payload.Length),
                outgoing, tracker);
        }

        /// <summary>
        /// Checks the limits that can be checked before sending, so that a call the server would
        /// refuse is never transferred. A file of unknown length is checked as it is sent.
        /// </summary>
        private void CheckLimits(long payloadLength, IReadOnlyList<FileContent> files, ServerSettings limits)
        {
            string violation = null;

            if (payloadLength > limits.MaxPayloadLength)
                violation = $"the parameters take {payloadLength} bytes, more than the {limits.MaxPayloadLength} allowed";
            else if (files.Count > limits.MaxFileCount)
                violation = $"{files.Count} files are uploaded, more than the {limits.MaxFileCount} allowed";
            else
            {
                long total = 0;
                foreach (var file in files)
                {
                    var length = KnownLength(file);
                    if (length > limits.MaxFileLength)
                    {
                        violation = $"file {file.FileName} is {length} bytes long, more than the {limits.MaxFileLength} allowed";
                        break;
                    }

                    total += length ?? 0;
                }

                if (null == violation && total > limits.MaxUploadLength)
                    violation = $"the files are {total} bytes long, more than the {limits.MaxUploadLength} allowed";
            }

            if (null != violation) throw LimitExceeded(violation);
        }

        private static long? KnownLength(FileContent file)
            => file.Content.CanSeek ? file.Content.Length - file.Content.Position : (long?)null;

        #endregion

        #region Response

        private (object Result, ClaimsIdentity Identity) ReadResponse(RemoteUseCaseDescriptor descriptor,
            DataPortalResponse response, ServerSettings settings)
        {
            using (response)
            {
                if (response.Kind == DataPortalResultKind.Error)
                {
                    var error = response.Error ?? new RemoteError();

                    // a call the server cannot read usually means that the server has been updated:
                    // the next call fetches the settings again and reports the mismatch
                    if (error.Kind == RemoteErrorKind.BadRequest) _settingsProvider.Invalidate();

                    throw ToException(error);
                }

                object result = null;

                switch (response.Kind)
                {
                    case DataPortalResultKind.None:
                        if (null != descriptor.Result && !descriptor.Result.AllowsNull) throw Mismatch();
                        break;

                    case DataPortalResultKind.File:
                        if (null == descriptor.Result || !descriptor.Result.IsFile) throw Mismatch();
                        result = response.TakeFile() ?? throw Mismatch();
                        break;

                    case DataPortalResultKind.Value:
                        if (null == descriptor.Result || descriptor.Result.IsFile
                            || response.ResultType != descriptor.Result.WireTypeName) throw Mismatch();
                        result = ReadValue(descriptor.Result, response.Value, settings.MaxDepth);
                        break;

                    default:
                        throw Mismatch();
                }

                return (result, response.RefreshedIdentity?.ToIdentity());
            }
        }

        private object ReadValue(RemoteValueDescriptor descriptor, ArraySegment<byte> value, int maxDepth)
        {
            if (null == value.Array) throw Mismatch();

            try
            {
                var serializer = DataPortalSerialization.CreateSerializer(maxDepth);
                serializer.Context = new StreamingContext(StreamingContextStates.Remoting, NoFiles.Instance);

                using (var textReader = new StreamReader(new MemoryStream(value.Array, value.Offset, value.Count, false), Utf8))
                using (var jsonReader = new JsonTextReader(textReader) { MaxDepth = maxDepth })
                {
                    if (!jsonReader.Read()) throw Mismatch();

                    var result = descriptor.Read(jsonReader, serializer, _context);

                    if (jsonReader.Read()) throw Mismatch();

                    return result;
                }
            }
            catch (RemoteCallRejectedException)
            {
                // the server has answered with something this client does not expect:
                // most likely the two are of different versions
                throw Mismatch();
            }
            catch (JsonException)
            {
                throw Mismatch();
            }
        }

        private Exception Mismatch()
        {
            // most likely the server has been updated since the settings were fetched
            _settingsProvider.Invalidate();
            return ToException(new RemoteError { Kind = RemoteErrorKind.BadRequest });
        }

        private Exception LimitExceeded(string violation)
            => ToException(new RemoteError { Kind = RemoteErrorKind.BadRequest },
                new InvalidOperationException($"The call exceeds the data portal limits: {violation}."));

        private Exception ToException(RemoteError error, Exception innerException = null)
            => _errorMapper.ToException(error) ?? new RemoteCallException(error, innerException);

        #endregion
    }
}
