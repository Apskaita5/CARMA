using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Reflection;
using A5Soft.CARMA.Domain;
using Newtonsoft.Json.Serialization;

namespace A5Soft.CARMA.Application.DataPortal
{
    /// <summary>
    /// A contract resolver for the values that cross the data portal (and the repository
    /// boundary): DTOs and POCOs as they are, read-only types (query results, lookups) through
    /// their constructor marked with <see cref="SerializationConstructorAttribute"/>.
    /// </summary>
    /// <remarks>
    /// <para>A serialization constructor may be private. Each of its parameters is matched,
    /// ignoring case, to a serialized property of the same name and type; a parameter without
    /// one is reported when the type is first used, rather than silently left at its default.</para>
    /// <para>A <see cref="QueryResultBase"/> has <see cref="QueryResultBase.CalculateSubtotals"/>
    /// invoked once it has been deserialized, so its derived columns are always consistent with
    /// the data and the serialization constructor need not take them.</para>
    /// </remarks>
    public class DataPortalContractResolver : DefaultContractResolver
    {
        private static readonly ConcurrentDictionary<Type, ConstructorInfo> Constructors
            = new ConcurrentDictionary<Type, ConstructorInfo>();


        /// <summary>
        /// Gets the constructor of the type marked with <see cref="SerializationConstructorAttribute"/>,
        /// or null if it has none.
        /// </summary>
        /// <param name="type">a type to inspect</param>
        /// <exception cref="InvalidOperationException">more than one constructor is marked</exception>
        public static ConstructorInfo GetSerializationConstructor(Type type)
        {
            if (null == type) throw new ArgumentNullException(nameof(type));

            return Constructors.GetOrAdd(type, t =>
            {
                var marked = t.GetConstructors(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                    .Where(c => c.IsDefined(typeof(SerializationConstructorAttribute), false))
                    .ToList();

                if (marked.Count > 1) throw new InvalidOperationException(
                    $"Type {t} has more than one constructor marked with [SerializationConstructor].");

                var constructor = marked.FirstOrDefault();

                // by convention a serialization constructor is private: it exists for the serializer only,
                // and nothing else may build a read-only object (a query result, a lookup) from raw values
                if (null != constructor && !constructor.IsPrivate) throw new InvalidOperationException(
                    $"The serialization constructor of {t} must be private.");

                return constructor;
            });
        }


        /// <inheritdoc />
        protected override JsonObjectContract CreateObjectContract(Type objectType)
        {
            var contract = base.CreateObjectContract(objectType);

            var constructor = GetSerializationConstructor(objectType);
            if (null != constructor)
            {
                var parameters = CreateConstructorParameters(constructor, contract.Properties);

                // Json.NET feeds a parameter only from a property of the same name and type;
                // any other parameter would silently get its default value
                var unmatched = constructor.GetParameters()
                    .Where(p => !contract.Properties.Any(c => !c.Ignored
                        && string.Equals(c.PropertyName, p.Name, StringComparison.OrdinalIgnoreCase)
                        && c.PropertyType == p.ParameterType))
                    .Select(p => p.Name)
                    .ToList();

                if (unmatched.Count > 0) throw new InvalidOperationException(
                    $"The serialization constructor of {objectType} has parameter(s) " +
                    $"{string.Join(", ", unmatched)} with no serialized property of the same name and type.");

                contract.OverrideCreator = args => constructor.Invoke(args);
                contract.CreatorParameters.Clear();
                foreach (var parameter in parameters) contract.CreatorParameters.Add(parameter);
            }

            if (typeof(QueryResultBase).IsAssignableFrom(objectType))
            {
                contract.OnDeserializedCallbacks.Add((value, context) =>
                    ((QueryResultBase)value).CalculateSubtotals());
            }

            return contract;
        }
    }
}
