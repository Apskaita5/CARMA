using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace A5Soft.CARMA.Application.DataPortal
{
    /// <summary>
    /// The only types that can be named on the wire: as the generic arguments of a generic remote method,
    /// or as a <see cref="Type"/> value in a parameter or a result. Everything else that crosses the data
    /// portal is described by the remote method signature, never by a name the other side has sent.
    /// </summary>
    /// <remarks>
    /// <para>Filled from the assembly scan (<see cref="IoC.IoCManagerBase"/>): every lookup type (deriving from
    /// <see cref="Domain.LookupBase{T}"/>) with its entity type, every remote use case interface and every
    /// implementation of one. A name is <see cref="Type.ToString"/>: no assembly name or version, so
    /// different builds of the client and the server match, as they do for use case names.</para>
    /// <para>Resolving a name never loads an assembly, runs a type initializer or reaches a type outside the
    /// list: an unknown name is simply not found, and the call is refused.</para>
    /// </remarks>
    public sealed class KnownTypes
    {
        private readonly ConcurrentDictionary<string, Type> _byName
            = new ConcurrentDictionary<string, Type>(StringComparer.Ordinal);


        /// <summary>Gets the types known, by their wire names.</summary>
        public IReadOnlyDictionary<string, Type> ByName => _byName;


        /// <summary>
        /// Gets the wire name of a type.
        /// </summary>
        public static string GetName(Type type)
            => (type ?? throw new ArgumentNullException(nameof(type))).ToString();

        /// <summary>
        /// Finds a known type by its wire name.
        /// </summary>
        public bool TryResolve(string name, out Type type)
        {
            type = null;
            return null != name && _byName.TryGetValue(name, out type);
        }

        /// <summary>
        /// Gets a value indicating whether a type is known.
        /// </summary>
        public bool Contains(Type type)
            => null != type && _byName.TryGetValue(GetName(type), out var known) && known == type;


        /// <summary>
        /// Adds a type; adding it again does nothing.
        /// </summary>
        /// <exception cref="InvalidOperationException">another type has the same wire name (the same full
        /// name in another assembly)</exception>
        internal void Add(Type type)
        {
            if (null == type) throw new ArgumentNullException(nameof(type));
            if (type.ContainsGenericParameters) throw new ArgumentException(
                $"An open generic type cannot be known: {type}.", nameof(type));

            var existing = _byName.GetOrAdd(GetName(type), type);
            if (existing != type) throw new InvalidOperationException(
                $"Types {existing.AssemblyQualifiedName} and {type.AssemblyQualifiedName} have the same name, " +
                "so the data portal cannot tell them apart.");
        }
    }
}
