﻿using System;

namespace A5Soft.CARMA.Application
{
    /// <summary>
    /// A base class for all use cases.
    /// </summary>
    /// <remarks>
    /// All use cases need logging.
    /// Pretty much all use cases deal with business entities and require
    /// validation and metadata access for that purpose.</remarks>
    public abstract class UseCaseBase<TAppContext> : IUseCase
        where TAppContext : IApplicationContext
        where TIdentity : CarmaIdentity
    {
        /// <summary>
        /// Application context and common services.
        /// </summary>
        protected readonly TAppContext Context;


        protected UseCaseBase(TAppContext context)
        {
            Context = context ?? throw new ArgumentNullException(nameof(context));
        }
    }
}
