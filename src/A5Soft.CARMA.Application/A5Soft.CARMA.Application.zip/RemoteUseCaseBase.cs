﻿namespace A5Soft.CARMA.Application
{
    /// <summary>
    /// A base class for use cases that support remote execution.
    /// </summary>
    public abstract class RemoteUseCaseBase<TAppContext> : UseCaseBase<TAppContext>
        where TAppContext : IApplicationContext
    {
        /// <inheritdoc />
        public RemoteUseCaseBase(TAppContext context) : base(context) {}
    }
}
