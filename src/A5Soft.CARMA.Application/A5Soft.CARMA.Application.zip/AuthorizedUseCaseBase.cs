﻿using A5Soft.CARMA.Application.Authorization;
using System;
using System.Security.Claims;
using System.Threading.Tasks;
using A5Soft.CARMA.Application.DataPortal;
using A5Soft.CARMA.Domain.Metadata;
using A5Soft.CARMA.Domain.Rules;
using A5Soft.CARMA.Application.Authorization.Identity;
using A5Soft.CARMA.Application.Authorization.Authorizers;

namespace A5Soft.CARMA.Application
{
    /// <summary>
    /// A base class for all use cases that implement authorization.
    /// </summary>
    /// <remarks>Authorization is only meaningful for remote execution.</remarks>
    public abstract class AuthorizedUseCaseBase<TAppContext, TIdentity> : RemoteUseCaseBase<TAppContext>, IAuthorizedUseCase
        where TAppContext : IApplicationContext
        where TIdentity : CarmaIdentity
    {
        /// <inheritdoc />
        protected AuthorizedUseCaseBase(TAppContext context) : base(context)
        {
        }


        /// <inheritdoc cref="IAuthorizedUseCase.GetIdentityAsync" />
        public Task<ClaimsIdentity> GetIdentityAsync()
        {
            return Context.AuthorizationProvider..GetIdentityAsync();
        }

        /// <inheritdoc cref="IAuthorizedUseCase.CanInvokeAsync" />
        public async Task<bool> CanInvokeAsync(bool throwOnNotAuthorized = false)
        {
            var currentIdentity = await _authenticationStateProvider.GetIdentityAsync();
            return Authorizer.IsAuthorized(currentIdentity, throwOnNotAuthorized);
        }
 
    }
}
