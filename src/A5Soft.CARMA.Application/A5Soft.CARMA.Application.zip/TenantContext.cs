﻿using A5Soft.CARMA.Domain;
using System;

namespace A5Soft.CARMA.Application
{
    [DefaultServiceImplementation(typeof(ITenantContext))]
    public sealed class TenantContext : ITenantContext
    {
        private string _tenantId;

        public bool IsInitialized { get; private set; }

        public string TenantId => IsInitialized ? _tenantId : throw new InvalidOperationException(
            "The tenant of this scope is not set yet: nothing tenant scoped can be resolved before it is.");

        public void Initialize(string tenantId)
        {
            if (IsInitialized) throw new InvalidOperationException("The tenant of a scope cannot change.");
            _tenantId = string.IsNullOrWhiteSpace(tenantId) ? null : tenantId;
            IsInitialized = true;
        }
    }
}
