﻿using A5Soft.CARMA.Application.Authorization.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace A5Soft.CARMA.Application.Authorization.Authorizers
{
    /// <summary>
    /// The authorization rules of a use case, read from its interface.
    /// </summary>
    public sealed class UseCaseAuthorizer : IUseCaseAuthorizer
    {
        /// <summary>Whether the interface declares any authorization attribute at all.</summary>
        private readonly bool _declared;
        private readonly IAuthorizationExceptionProvider _exceptionProvider;


        /// <summary>
        /// Reads the authorization rules of a use case interface.
        /// </summary>
        /// <param name="useCaseInterface">the use case interface carrying the authorization attributes</param>
        /// <param name="catalog">the permission catalog, holding an instance of every permission type</param>
        /// <param name="exceptionProvider">provider for localized exceptions</param>
        /// <exception cref="ArgumentNullException">a parameter is null</exception>
        public UseCaseAuthorizer(Type useCaseInterface, PermissionCatalog catalog, IAuthorizationExceptionProvider exceptionProvider)
        {
            UseCaseType = useCaseInterface ?? throw new ArgumentNullException(nameof(useCaseInterface));
            _exceptionProvider = exceptionProvider ?? throw new ArgumentNullException(nameof(exceptionProvider));
            if (null == catalog) throw new ArgumentNullException(nameof(catalog));

            var authorize = useCaseInterface.GetCustomAttribute<AuthorizeAttribute>(false);
            AllowsAnonymous = useCaseInterface.IsDefined(typeof(AllowAnonymousAttribute), false);
            AllowsSecondFactorPending = useCaseInterface.IsDefined(typeof(AllowSecondFactorPendingAttribute), false);
            AllowsAdminOnly = useCaseInterface.IsDefined(typeof(AllowAdminOnlyAttribute), false);
            Permissions = authorize?.PermissionTypes.Select(catalog.Get).ToList() ?? new List<Permission>();
            _declared = null != authorize || AllowsAnonymous || AllowsSecondFactorPending || AllowsAdminOnly;
        }


        /// <inheritdoc />
        public Type UseCaseType { get; }

        /// <inheritdoc />
        public bool AllowsAnonymous { get; }

        /// <inheritdoc />
        public bool AllowsSecondFactorPending { get; }

        /// <inheritdoc />
        public bool AllowsAdminOnly { get; }

        /// <inheritdoc />
        public IReadOnlyList<Permission> Permissions { get; }


        /// <inheritdoc />
        public bool CanInvoke(CarmaIdentity identity) => null == Refuse(identity);

        /// <inheritdoc />
        public void EnsureCanInvoke(CarmaIdentity identity)
        {
            var refusal = Refuse(identity);
            if (null != refusal) throw refusal;
        }

        /// <summary>
        /// Gets the reason to refuse an identity, in the order: no authorization declared, anonymous, second factor
        /// pending, none of the permissions held.
        /// </summary>
        /// <param name="identity">the identity to check; null is treated as anonymous</param>
        /// <returns>the exception to throw; null if the identity may invoke the use case</returns>
        private Exception Refuse(CarmaIdentity identity)
        {
            if (!_declared) return new InvalidOperationException($"Use case {UseCaseType.FullName} declares no " +
                $"authorization: mark it with {nameof(AuthorizeAttribute)}, {nameof(AllowAnonymousAttribute)}" +
                $", {nameof(AllowSecondFactorPendingAttribute)}, or {nameof(AllowAdminOnlyAttribute)}.");

            if (AllowsAnonymous) return null;

            if (null == identity || identity.IsAnonymous) return new NotAuthenticatedException();

            if (AllowsAdminOnly && !identity.IsAdmin) return _exceptionProvider.ExceptionForAdmin() ??
                throw new InvalidOperationException("IAuthorizationExceptionProvider returned null exception.");

            if (identity.IsSecondFactorPending) return AllowsSecondFactorPending
                ? null : new NotAuthenticatedException("Provide the second factor first.");

            if (Permissions.Count < 1 || identity.HasAnyPermission(Permissions)) return null;

            return _exceptionProvider.ExceptionForPermissions(Permissions) ??
                throw new InvalidOperationException("IAuthorizationExceptionProvider returned null exception.");
        }
    }
}
